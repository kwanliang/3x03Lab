import pytest
from selenium import webdriver
import webdriver_manager
from webdriver_manager.chrome import ChromeDriverManager
from webdriver_manager.firefox import GeckoDriverManager
from webdriver_manager.microsoft import EdgeChromiumDriverManager
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from time import sleep

#Fixture for Chrome, Firefox, Edge
#@pytest.fixture(params=["Edge"],scope="class")
@pytest.fixture(params=["chrome"],scope="class")
def driver_init(request):
    if request.param == "chrome":
        opt = webdriver.ChromeOptions()
        #opt.headless = True
        opt.add_argument('--no-sandbox')
        opt.add_argument("--disable-dev-shm-usage")
        opt.add_argument('--disable-gpu')
        web_driver = webdriver.Chrome(ChromeDriverManager().install(), options=opt)
    request.cls.driver = web_driver
    yield
    web_driver.close()


@pytest.mark.usefixtures("driver_init")
class Test:
    pass


website = 'http://localhost:5000'
class Test_GUI(Test):

        def test_WebsiteAliveDead(self):
            self.driver.get(website + "/")
            sleep(3)
            assert 'search' in self.driver.page_source

        # def test_LoginNoReCaptcha(self):
        #     self.driver.get(website + "/login")
        #     sleep(3)
        #     self.driver.find_element(By.ID, 'email').send_keys('Derricktoh51@gmail.com')
        #     self.driver.find_element(By.ID, 'password').send_keys('blahblahblah')
        #     self.driver.execute_script("arguments[0].click();", self.driver.find_element(By.NAME, 'Login'))
        #     sleep(5)
        #     assert self.driver.title == 'Login'
        #     assert 'Please fill out the ReCaptcha.' in self.driver.page_source
